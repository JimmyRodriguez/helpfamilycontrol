<html>
    
    <body>
        <p>

Hi there [[username]], 
</p>
        
        <p>
Your email address at [[oursite]] has been changed. As a security & anti spam measure you must re-activate
your account to verify you're email address.
</p>
<p>
<a href='[[actiurl]]'>[[actiurl]]</a>
</p>
<p>
You can copy and past in the url in to a new window. If that does not work then type in
this two part code in at <a href='[[actiurl-sans-code]]'>[[actiurl-sans-code]]</a>
</p>
<p>
Part A: <strong>[[parta]]</strong>
     </p>
<p>
Part B: <strong>[[partb]]</strong>
</p>
<p>
Once your account is activated you can login at [[oursite]].
</p>
<p>
Thanks
</p>
<p>
Member Registration Team
</p>

    </body>
    
</html>
