<head></head>

<html>
    <body>
            ##data_table##
            <br/>
            
            <p>##name_email##</p>
       
            
            ##msg##
    </body>
</html>
