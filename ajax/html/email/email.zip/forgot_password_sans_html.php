<html>
   
    <body>
        <pre>
        <p>
        Hi there [[username]], 
        </p>
            
        <p>
        A temporary password has been set for your account:
        </p>
    
        <p>
        your temporary password is: <strong>[[temppass]]</strong>
        </p>
    
        <p>
        your username is: <strong>[[username]]</strong>
        </p>
    
        <p>
        Please use this to login and change your password.
        </p>
    
        <p>
        Kind regards
        </p>
    
        <p>
        The Admin Team
        </p>
        
        
    </body>
    
</html>




