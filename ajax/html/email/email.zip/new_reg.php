<html>
    
    <body>
        <p>

Hi there, 
 </p>
        
     <p>   
Your account at [[site]] has been created!
 </p>
     <p>
There is no need to activate your account, you can go ahead and log in at [[site]]
 </p>
     <p>
Your transaction/order id for this payment: [[tranid]]
 </p>
     <p>
It's great to have you on board. If you have any questions head down to the support forums for a chat.
 </p>

<p>
Thanks
 </p>

<p>
Member Registration Team


    </p>

    </body>
    
</html>