<html>
    
    <body>
        <p>

            Hi there [[username]],
            </p>
             <p>
            Your account at [[oursite]] has been activated successfully!
            </p>
             <p>
            Hope to see you soon!
            </p>
            
             <p>
            Kind regards
            </p>
             <p>
            The Admin Team

    </p>
    </body>
    
</html>