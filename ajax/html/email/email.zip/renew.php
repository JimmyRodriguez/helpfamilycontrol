<html>
    
    <body>
        <p>



Hi there,

</p>
 <p>
Just to let you know that your account down at [[site]] has been renewed. 

</p>
  <p>
Your transaction/order id for this payment: [[tranid]]
</p>
   <p>
If you have any questions head down to the support forums for a chat. If you have any billing queries then
use our 'contact us' form on our site.
</p>

 <p>
Thanks
</p>

 <p>
Member Registration Team

</p>

    </body>
    
</html>