<html>
    
    <body>
        <p>

Hi there [[username]],
        </p>
<p>
Your account at [[oursite]] has been created. Once the site administrator has verified
your account your account will be activated.
</p>
<p>
Once your account is activated you can login and join the party at [[oursite]].
</p>
<p>
Thanks
</p>
<p>
Member Registration Team
</p>
    </pre>
    </body>
    
</html>