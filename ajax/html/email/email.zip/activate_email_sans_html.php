<html>
    
    <body>
            <p>
                Hi there [[username]], 
            </p>
            
            <p>
                Your account at [[oursite]] has been created. All you need to do now is confirm this is your
                email address by clicking the link below:
            </p>
            <p>
                <a href='[[actiurl]]'>[[actiurl]]</a>
            </p>
            <p>
                You can copy and past in the url in to a new window. If that does not work then type in
                this two part code in at <a href='[[actiurl-sans-code]]'>[[actiurl-sans-code]]</a>
            </p>
            <p>
                Part A: <strong>[[parta]]</strong>
            </p>
            <p>
                Part B: <strong>[[partb]]</strong>
            </p>
            
            <p>
                Once your account is activated you can login and join the party at [[oursite]].
            </p>
            <p>
                Thanks
            </p>
            <p>
                Member Registration Team
            </p>
        </pre>
    </body>
    
</html>

