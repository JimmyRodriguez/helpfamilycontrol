<table>
                <tr>
                    <td>
                        send by:
                    </td>
                    <td>
                       ##name##
                    </td>
                </tr>
                <tr>
                    <td>
                        username:
                    </td>
                    <td>
                        <a href='##admin_path##unibody.php?userid=##userid##'>##username##</a>
                    </td>
                </tr>
                <tr>
                    <td>
                        email address on our records:
                    </td>
                    <td>
                        ##email##
                    </td>
                </tr>
                <tr>
                    <td>
                        email used in contact form
                    </td>
                    <td>
                        ##email_contact##
                    </td>
                </tr>
                
            </table>