<html>
    
    <body>
       <p>
        Hi there [[username]], 
        </p>
        <p>
        Just to let you know that your password at [[oursite]] has been changed successfully!
        </p>
        
        <p>
        Hope to see you soon!
        </p>
        
        <p>
        Kind regards
        </p>
        
        <p>
        The Admin Team
            </p>
    </body>
    
</html>
